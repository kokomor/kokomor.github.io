<!DOCTYPE html>
<html>
<head>
	<title>BroTube</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
	<main>
		<div class="fixed" id="header"><span>BroTube</span></div>
		<div class="fixed" id="buttonsArea">
			<!-- начало кнопки -->
			<form action="https://www.youtube.com">
				<button class="textBig" id="butBro" type="submit">
					головна сторiнка
				</button>
			</form>
			<form action="https://www.youtube.com/feed/trending">
				<button class="textBig" id="butBro" type="submit">
					фигня повна
				</button>
			</form>
			<form action="https://www.youtube.com/feed/subscriptions">
				<button class="textBig" id="butBro" type="submit">
					Пiдписки
				</button>
			</form>
			<form action="https://www.youtube.com/feed/history">
				<button class="textBig" id="butBro" type="submit">
					HISTORY
				</button>
			</form>

			<!-- конец кнопки -->
		</div>
		<div id="page">
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
			<div class="card">
				<img src="card.jpg">
				<div id="name">Video</div>
				<div id="description"> desc</div>
			</div>
		</div>
	</main>
</body>
</html>